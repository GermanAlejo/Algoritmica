/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epd03.p2;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author manuel
 */
public class Gene {

    // Generic parameters:
    // Number of nodes in graph
    public static final int SIZE = 100;
    // Adyancency matrix (nodes with themselves will have a value of 0)
    public static int[][] MATRIX;
    /*public static int[][] MATRIX = {
        {1, 1, 0, 0, 0 },
        {1, 1, 0, 0, 0 },
        {0, 0, 1, 1, 1 },
        {0, 0, 1, 1, 0 },
        {0, 0, 1, 0, 1 }
    }; // solution to this matrix is 2*/
    public static ArrayList colors;

    // Genetic parameters
    // Max iterations (it has to be big enough to account for bad individuals)
    public static final int MAX_EVOLUTIONS = 200;
    // Pool of individuals in population (it has to be big enough to account for bad individuals)
    public static final int POPULATION_SIZE = 250;
    // Percent of elite individuals
    public static final double ELITE_PERCENT = 0.1;
    // Chance of selecting an elite parent in crossover phase
    public static final double ELITE_PARENT_RATE = 0.1;
    // Chance of directly cloning the best parent in crossover phase
    public static final double PARENT_CLONE_CHANCE = 0.05;
    // Chance of mutation
    public static final double MUTATION_CHANCE = 0.25;
    // Size of tournament groups
    public static final int TOURNAMENT_POPULATION = 10;
    // Chance of a mutation/crossover validity enforcement
    public static final double CHANGE_VALIDITY_ENFORCEMENT = 0.5;
    // Prevents tje eugenic methods from getting stuck
    public static final int MAX_VALIDITY_ENFORCEMENT = 25;

    public static void main(String[] args) {
        Random r = new Random();
        MATRIX = new int[SIZE][SIZE];
        for (int i = 0; i < SIZE; i++) {
            for (int j = i; j < SIZE; j++) {
                if (i == j) {
                    MATRIX[i][j] = 1;
                } else {
                    int x = r.nextInt(2);
                    MATRIX[i][j] = x;
                    MATRIX[j][i] = x;
                }
            }
        }
        Population pop = new Population(SIZE);
        pop.initializePopulationRandomly();
        colors = new ArrayList();
        int bestSolution = Integer.MAX_VALUE;
        int bestIteration = 0;

        int i = 0;
        long start = System.currentTimeMillis();
        while (i < MAX_EVOLUTIONS) {
            // STEP 1: Evolve the populaton
            pop = pop.evolve();

            // STEP 2: Evaluate the new population
            Individual bestIndividual = pop.getBestIndividualInPop();
            int currentBestSolution = bestIndividual.getCost();
            if (currentBestSolution < bestSolution) {
                bestSolution = currentBestSolution;
                bestIteration = i;
                System.out.println("New best found! Cost: " + bestSolution + ", found in iteration " + i);
            }

            if (i % 10 == 0) {
                System.out.println("Finished Iteration: " + i + ". Best Solution: " + bestIndividual.toString());
            }

            i++;
        }
        long end = System.currentTimeMillis();
        System.out.println("Final solution: " + bestSolution + ", found in iteration: " + bestIteration);
        System.out.println("Total time: " + ((double) (end - start)) / 1000 + " seconds");
    }
}
