/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epd03.p2;

import java.util.*;

/**
 *
 * @author Manuel
 */
public class Individual {

    // Indexes are nodes, values are colors
    ArrayList<Integer> tour;
    private int cost;

    public Individual() {
        this.tour = new ArrayList<>();
    }

    public void initializeRandomly(int size) {
        // At first, there will be as many colors as nodes.
        Random r = new Random();
        for (int i = 0; i < size; i++) {
            tour.add(i);
        }
        Collections.shuffle(tour);
        // calculate the cost when the individual is created
        calculateCost();
    }

    public int getCost() {
        return cost;
    }

    // this method has to be called upon creation or modification(ie mutation), or the algorithm won't work
    public void calculateCost() {
        /* This block of code manually creates a valid solution, but we dont need it. We want the algorithm to build it
        for us*/
 /*int i = 0;
        while (i<Gene.SIZE) {
            ArrayList<Integer> neighboringColors = getNeighboringColors(tour.get(i));
            // If there are no existing colors available, create one and assign it to node i
            if (neighboringColors.containsAll(Gene.colors)) { //this may not be what you think it is
                int newColor = Gene.colors.size();
                Gene.colors.add(newColor);
                tour.add(newColor);
            } else { // Search for a random available color and assign it to node i
                int availableColor = getRandomAvailableColor (tour.get(i));
                tour.add(i);                
            }            
        }*/
        // Non valid individuals will have a cost of Integer.MAX_VALUE so they get noscoped on sight
        if (isValidSolution()) {
            ArrayList<Integer> usedColors = new ArrayList<>();
            for (int i = 0; i < Gene.SIZE; i++) {
                if (!usedColors.contains(tour.get(i))) {
                    usedColors.add(tour.get(i));
                }
            }
            this.cost = usedColors.size();
        } else {
            this.cost = Integer.MAX_VALUE;
        }
    }

    @Override
    public String toString() {
        StringBuilder build = new StringBuilder();
        build.append("Individual (" + cost + "): ");
        for (int i : tour) {
            build.append(i + " ");
        }
        return build.toString();
    }

    private ArrayList getNeighboringColors(Integer nodeIndex) {
        /* Returns a list of the colors from the nodes that are adyacent to parameter node in the tour: ie, the non valid colors. */
        ArrayList<Integer> neighborColors = new ArrayList<>();
        for (int i = 0; i < nodeIndex; i++) {
            if (Gene.MATRIX[nodeIndex][i] == 1) {
                neighborColors.add(this.tour.get(i));
            }
        }
        return neighborColors;
    }

    /*private int getRandomAvailableColor(Integer get) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/
    public boolean isValidSolution() {
        // Searches for a node (ie an index in the tour) whose neighbors have the same color that it (ie the same value that the index)
        boolean valid = true;
        int i = 0;
        while (i < Gene.SIZE && valid) {
            ArrayList<Integer> neighborColors = getNeighboringColors(i);
            valid = !neighborColors.contains(tour.get(i));
            i++;
        }
        return valid;
    }
}
