/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epd03.p2;

import java.util.*;

/**
 *
 * @author Manuel
 */
public class Population {

    ArrayList<Individual> population;
    int sizeOfIndividual;
    ArrayList<Individual> sortedPop;
    Random r;

    public Population(int size) {
        population = new ArrayList<>();
        this.sizeOfIndividual = size;
        r = new Random();
    }

    public void initializePopulationRandomly() {
        // First generation will all have the same value
        for (int i = 0; i < Gene.POPULATION_SIZE; i++) {
            Individual ind = new Individual();
            ind.initializeRandomly(sizeOfIndividual);
            population.add(ind);
        }
    }

    public Population evolve() {
        // we will need a sorted pop for elitism
        sortedPop = new ArrayList<>();
        Population nextGen = new Population(sizeOfIndividual);
        // keeps track of how much space is left in nextGen
        int popAvailable = population.size();

        // STEP 1: Sort the population, take the best individual no questions asked
        sortPopulation();

        // from here, individuals is empty, and sortedPop has all the individuals sorted from best to worst
        // add the top individual
        nextGen.population.add(sortedPop.get(0));
        popAvailable--;

        // STEP 2: Add top individuals to nextgen, mutate if necessary
        int numElite = (int) (Gene.POPULATION_SIZE * Gene.ELITE_PERCENT);
        for (int i = 0; i < numElite; i++) {
            // there is a MUTATION_CHANCE chance of mutation in this step
            if (r.nextDouble() < Gene.MUTATION_CHANCE) {
                nextGen.population.add(mutate(sortedPop.get(i)));
                // get the recently mutated element and recalculate its cost
                nextGen.population.get(nextGen.population.size() - 1).calculateCost();
            } else {
                nextGen.population.add(sortedPop.get(i));
                // get the recently mutated element and recalculate its cost (just in case)
                nextGen.population.get(nextGen.population.size() - 1).calculateCost();
            }
            popAvailable--;
        }

        // STEP 3: Create offspring given two parents 
        while (popAvailable > 0) {
            // STEP 3.1: select parents via tournament, and generate children
            Individual i1 = selectIndividualByTournament();
            Individual i2 = selectIndividualByTournament();
            Individual child = crossover(i1, i2);

            //STEP 3.1: apply small chance of mutation
            if (r.nextDouble() < Gene.MUTATION_CHANCE) {
                mutate(child);
            }

            // always calculate cost
            child.calculateCost();

            // now, new child is done, so add to nextGen
            nextGen.population.add(child);
            popAvailable--;
        }
        return nextGen;
    }

    private void sortPopulation() {
        for (int i = 0; i < Gene.POPULATION_SIZE; i++) {
            int bestCost = Integer.MAX_VALUE;
            int bestIndex = 0;
            // finds the best individual among those remaining in population and not in sortedPop
            for (int j = 0; j < population.size(); j++) {
                int nextValue = population.get(j).getCost();
                if (nextValue < bestCost) {
                    bestCost = nextValue;
                    bestIndex = j;
                }
            }
            // add the best found individual to sorted
            sortedPop.add(population.get(bestIndex));
            population.remove(bestIndex);
        }
    }

    public Individual getBestIndividualInPop() {
        // returns the individual with cost closest to 0
        Individual bestInd = population.get(0);
        int bestValue = Integer.MAX_VALUE;

        for (Individual ind : population) {
            int indCost = ind.getCost();
            if (indCost < bestValue) {
                bestInd = ind;
                bestValue = indCost;
            }
        }
        return bestInd;
    }

    private Individual mutate(Individual ind) {
        // We will define a mutation as a permutaion of elements (mutations can completely ruin a solution)
        Integer aux;
        int i, j;
        /*// OPTION 1: Let mutations ruin a solution (faster but less good)        
        do {
            i = r.nextInt(sizeOfIndividual);
            j = r.nextInt(sizeOfIndividual);
        } while (i == j);
        aux = ind.tour.get(i);
        ind.tour.set(i, ind.tour.get(j));
        ind.tour.set(j, aux);
        // OPTION 2: Don't let mutations ruin a solution (slower but more good)
        do {
            do {
                i = r.nextInt(sizeOfIndividual);
                j = r.nextInt(sizeOfIndividual);
            } while (i == j);
            aux = ind.tour.get(i);
            ind.tour.set(i, ind.tour.get(j));
            ind.tour.set(j, aux);
        } while (!ind.isValidSolution());*/

        // OPTION 3: Controlled chance of not letting mutations ruin a solution(so I don't run out of patience)
        int x = 0;
        if (r.nextDouble() < Gene.CHANGE_VALIDITY_ENFORCEMENT) {
            do {
                do {
                    i = r.nextInt(sizeOfIndividual);
                    j = r.nextInt(sizeOfIndividual);
                } while (i == j);
                aux = ind.tour.get(i);
                ind.tour.set(i, ind.tour.get(j));
                ind.tour.set(j, aux);
                x++;
            } while (!ind.isValidSolution() && x < Gene.MAX_VALIDITY_ENFORCEMENT);
        } else {
            do {
                i = r.nextInt(sizeOfIndividual);
                j = r.nextInt(sizeOfIndividual);
            } while (i == j);
            aux = ind.tour.get(i);
            ind.tour.set(i, ind.tour.get(j));
            ind.tour.set(j, aux);
        }
        return ind;
    }

    private Individual selectIndividualByTournament() {
        Individual res = null;
        // OPTION 1: Chance to return parent from elite population (elite population is top ELITE_PERCENT percent of sortedPop
        if (r.nextDouble() < Gene.ELITE_PARENT_RATE) {
            int numOfEliteIndividuals = (int) (Gene.POPULATION_SIZE * Gene.ELITE_PERCENT);
            res = sortedPop.get(r.nextInt(numOfEliteIndividuals));
        } else {
            // OPTION 2: select a parent from the general population with a uniform distribution
            ArrayList<Individual> tournament = new ArrayList<>();
            for (int i = 0; i < Gene.TOURNAMENT_POPULATION; i++) {
                int randomIndex = r.nextInt(sortedPop.size());
                tournament.add(sortedPop.get(randomIndex));
            }
            res = getBestIndividual(tournament);
        }
        return res;
    }

    private Individual selectParentViaRoulette() {
        // The chance of an individual being selected is directly proportional to its aptitude
        Individual res;
        // STEP 1: We need a vector of INVERSE cost of each individual.
        // This way, the bigger the cost of the individual, the smaller its inverse value, and the least likely it will be selected
        double[] inversePop = new double[sortedPop.size()];
        for (int i = 0; i < sortedPop.size(); i++) {
            inversePop[i] = 1 / sortedPop.get(i).getCost();
        }

        // STEP 2: Calculate the totalFitness of inversePop
        double totalFitness = 0;
        for (int i = 0; i < sortedPop.size(); i++) {
            totalFitness += inversePop[i];
        }

        // STEP 3: Select by roulette. We use a random value, and the last element to substract that value to 0 wins. The smaller its cost, the more it will substract
        int j = 0;
        double rouletteSpot = r.nextDouble();
        while (j < sortedPop.size() && rouletteSpot > 0) {
            rouletteSpot -= inversePop[j] / totalFitness;
            j++;
        }
        // STEP 4: Return the last individual where rouletteSpot was still above 0 
        return sortedPop.get(j - 1);
    }

    private Individual crossover(Individual i1, Individual i2) {
        Individual child;
        int x = 0;
        // Chance of applying eugenics (see mutation() for a complete explanation)
        if (r.nextDouble() < Gene.CHANGE_VALIDITY_ENFORCEMENT) {
            do {
                // creates a child individual from two parents, with a small chance of just cloning a parent
                child = new Individual();
                if (r.nextDouble() < Gene.PARENT_CLONE_CHANCE) {
                    // STEP 1: Take a random amount of elements from i1
                    int elementsFromI1 = r.nextInt(Gene.SIZE);
                    for (int i = 0; i < elementsFromI1; i++) {
                        child.tour.add(i1.tour.get(i));
                    }
                    // STEP 2: Fill with elements from i2, no need to check for repetitions in this problem
                    for (int i = elementsFromI1; i < Gene.SIZE; i++) {
                        child.tour.add(i2.tour.get(i));
                    }
                } else {
                    child = (i1.getCost() < i2.getCost()) ? i1 : i2;
                }
                x++;
            } while (!child.isValidSolution() && x < Gene.MAX_VALIDITY_ENFORCEMENT);
        } else { // Eugenics-free breeding
            // creates a child individual from two parents, with a small chance of just cloning a parent
            child = new Individual();
            if (r.nextDouble() > Gene.CHANGE_VALIDITY_ENFORCEMENT) {
                // STEP 1: Take a random amount of elements from i1
                int elementsFromI1 = r.nextInt(Gene.SIZE);
                for (int i = 0; i < elementsFromI1; i++) {
                    child.tour.add(i1.tour.get(i));
                }
                // STEP 2: Fill with elements from i2, no need to check for repetitions in this problem
                for (int i = elementsFromI1; i < Gene.SIZE; i++) {
                    child.tour.add(i2.tour.get(i));
                }
            } else {
                child = (i1.getCost() < i2.getCost()) ? i1 : i2;
            }
        }
        return child;
    }

    private Individual getBestIndividual(ArrayList<Individual> tournament) {
        // returns the individual with cost closest to 0 in tournament
        Individual bestInd = tournament.get(0);
        int bestValue = Integer.MAX_VALUE;
        for (Individual ind : tournament) {
            int indCost = ind.getCost();
            if (indCost < bestValue) {
                bestInd = ind;
                bestValue = indCost;
            }
        }
        return bestInd;
    }
}
