/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

/**
 *
 * @author GermánAlejo
 */
public class ProblemFunc {

    private int[][] flow;
    private int[][] loc;

    public int[][] getLoc() {
        return loc;
    }

    public void setLoc(int[][] loc) {
        this.loc = loc;
    }

    public int[][] getFlow() {
        return flow;
    }

    public void setFlow(int[][] flow) {
        this.flow = flow;
    }

    //preguntar esta funcion en funcion a que cambia el fitness?
    public int getFitnessValue() {

        int fitness = 0;

        for (int i = 0; i < this.getLoc().length; i++) {
            for (int j = i + 1; j < this.getLoc().length; j++) {
                fitness += this.getLoc()[i][j] * this.getFlow()[i][j];
            }
        }

        return fitness;
    }

}
