/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;


/**
 *
 * @author GermánAlejo
 */
public class Particle {

    private int fitnessValue;
    private Location location;
    private Velocity velocity;

    public Particle() {
        super();
    }

    public Particle(int fitnessValue, Location location) {
        super();
        this.fitnessValue = fitnessValue;
        this.location = location;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Velocity getVelocity() {
        return velocity;
    }

    public void setVelocity(Velocity velocity) {
        this.velocity = velocity;
    }
    
//    public int getFitnessValue(){
//        //calcular fitness de la particula
//    }
   

}
