/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

/**
 *
 * @author GermánAlejo
 */
public interface PSOConstans {

    
    int NUM_BUILDINGS = 6;
    int MAX_ITERATION = 10;
    int PROBLEM_DIMENSION = 2;
    double C1 = 2.0;
    double C2 = 2.0;
    double W_UPPERBOUND = 1.0;
    double W_LOWERBOUND = 0.0;
}
