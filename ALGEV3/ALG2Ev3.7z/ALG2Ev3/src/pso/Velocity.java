/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

/**
 *
 * @author GermánAlejo
 */
public class Velocity {
    
    private int[] vel;
    
    public Velocity(int[] vel){
        this.vel=vel;
       
    }

    public int[] getVel() {
        return vel;
    }

    public void setVel(int[] vel) {
        this.vel = vel;
    }
    
    
    
}
