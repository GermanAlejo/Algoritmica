/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author GermánAlejo
 */
public class PSOProcess {

    int SWARM_SIZE = 10;
    int MATRIX_TAM = 6;
    int MAX_VELOCITY = 5;
    int MIN_VELOCITY = 0;
    int MAX_FLOW = 100;
    int MIN_FLOW = 0;
    int MAX_ITERATIONS = 10;

    //lista of all particles
    List<Particle> swarm = new ArrayList<>();
    //list of the best locations of each particle
    List<Location> pBestLocation = new ArrayList<>();

    //array with all the swarm´s fitness
    int[] fitnessValueList = new int[SWARM_SIZE];
    //array with best fitness of each particle
    int[] pBest = new int[SWARM_SIZE];
    
    int gBest;//fitness of the best solution in the swarm
    Location gBestLocation;//best location of the best solution
    
    Random rn = new Random();

    
    public void execute() {
        
        initializeSwarm();//initialize swarm
        updateFitnessList();//fill fitness list with the initial fitness values

        int t = 0;

        //fill the array and the list with initial values
        for (int i = 0; i < SWARM_SIZE; i++) {
            pBest[i] = fitnessValueList[i];
            pBestLocation.add(swarm.get(i).getLocation());
        }

        //the loop ends whith the max iterations 
        while (t < MAX_ITERATIONS) {

            //update pBest
            for (int i = 0; i < SWARM_SIZE; i++) {
                if (fitnessValueList[i] < pBest[i]) {
                    pBest[i] = fitnessValueList[i];
                    pBestLocation.set(i, swarm.get(i).getLocation());
                }
            //update gBest
                if (pBest[i] < gBest) {
                    gBest=pBest[i];
                    gBestLocation = pBestLocation.get(i);
                }
            }
            
            //Calculate new velocities and update locations
            for(int i=0;i<SWARM_SIZE;i++){
                
                //calculate new velocities
                
                
            }

            t++;
        }

    }

    public void initializeSwarm() {

        Particle p;

        //inicialize location
        for (int n = 0; n < SWARM_SIZE; n++) {

            p = new Particle();

            int[][] flow = new int[MATRIX_TAM][MATRIX_TAM];
            int[][] loc = new int[MATRIX_TAM][MATRIX_TAM];
            int[] vel = new int[MATRIX_TAM];
            List<Integer> kList = new ArrayList<>();
            int aux, f;
            Location l = null;
            Velocity v;

            for (int i = 0; i < MATRIX_TAM; i++) {
                for (int j = 0; j < MATRIX_TAM; j++) {

                    do {
                        aux = rn.nextInt() * 7 - 1;
                    } while (kList.contains(aux));

                    kList.add(aux);
                    loc[i][j] = aux;

                    f = rn.nextInt() * MAX_FLOW - MIN_FLOW;
                    flow[i][j] = f;

                    //need to change and check this
                    //l = new Location(loc, flow);
                }
                //HAVE TO RESET THE LIST(kList)

                //inicilize velocity
                vel[i] = rn.nextInt() * MAX_VELOCITY - MIN_VELOCITY;
                v = new Velocity(vel);

                p.setLocation(l);
                p.setVelocity(v);
                swarm.add(p);
            }

        }
    }

    public void updateFitnessList() {
        for (int i = 0; i < SWARM_SIZE; i++) {
           // fitnessValueList[i] = swarm.get(i).getFitnessValue();
        }
    }

}
